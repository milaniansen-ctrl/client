@echo off
setlocal
cd /d "%~dp0"
echo ========================================
echo FY4X Client - Fabric build
echo ========================================
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found. Install Java 21 and reopen this window.
  pause
  exit /b 1
)
java -version 2>&1 | findstr /C:"21." >nul
if errorlevel 1 echo WARNING: This project targets Java 21. Check your installed Java version.
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle was not found on PATH.
  echo Install Gradle 8.14 or newer, then reopen this window and run build.bat again.
  echo You also need internet access so Gradle can download Minecraft and Fabric dependencies.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Read the errors above.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCEEDED. Check the build\libs folder for the JAR.
explorer "%~dp0build\libs"
pause
