package com.alienmc.fy4x;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Pick a HUD card, then move it with arrow buttons. Cards stay visible behind this screen. */
public final class FY4XHudEditorScreen extends Screen {
    private FY4XHud.El selected = FY4XHud.El.WATERMARK;
    private int step = 5;
    private boolean dragging;
    private double dragX, dragY;

    public FY4XHudEditorScreen() { super(Text.literal("FY4X HUD Editor")); }

    @Override
    protected void init() {
        clearChildren();
        int y = 22, x = width - 150;
        for (FY4XHud.El e : FY4XHud.El.values()) {
            addDrawableChild(ButtonWidget.builder(Text.literal((e == selected ? "▶ " : "") + e.label).formatted(e == selected ? Formatting.AQUA : Formatting.WHITE),
                b -> { selected = e; clearAndInit(); }).dimensions(x, y, 140, 18).build());
            y += 20;
        }
        y += 6;
        addDrawableChild(ButtonWidget.builder(Text.literal(FY4XHud.on(selected) ? "Shown: ON" : "Shown: OFF"),
            b -> { FY4XHud.setOn(selected, !FY4XHud.on(selected)); clearAndInit(); }).dimensions(x, y, 140, 18).build());
        y += 24;
        int cx = x + 55;
        addDrawableChild(ButtonWidget.builder(Text.literal("▲"), b -> move(0, -step)).dimensions(cx, y, 30, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("◀"), b -> move(-step, 0)).dimensions(cx - 34, y + 20, 30, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("▶"), b -> move(step, 0)).dimensions(cx + 34, y + 20, 30, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("▼"), b -> move(0, step)).dimensions(cx, y + 40, 30, 18).build());
        y += 66;
        addDrawableChild(ButtonWidget.builder(Text.literal("Step: " + step + " px"), b -> { step = step == 1 ? 5 : step == 5 ? 20 : 1; clearAndInit(); })
            .dimensions(x, y, 140, 18).build());
        y += 20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset this card"), b -> {
            FY4XHud.setPos(selected, selected.dx, selected.dy); clearAndInit();
        }).dimensions(x, y, 140, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> { if (client != null) client.setScreen(new FY4XScreen()); })
            .dimensions(x, height - 26, 140, 18).build());
    }

    private void move(int dx, int dy) {
        int nx = Math.max(0, Math.min(width - 20, FY4XHud.x(selected) + dx));
        int ny = Math.max(0, Math.min(height - 14, FY4XHud.y(selected) + dy));
        FY4XHud.setPos(selected, nx, ny);
    }

    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { /* no blur */ }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x552080B0);
        ctx.fill(width - 156, 0, width, height, 0xF20A111B);
        for (FY4XHud.El e : FY4XHud.El.values()) {
            if (FY4XHud.on(e) || e == selected) FY4XHud.drawCard(ctx, client, e, e == selected);
        }
        ctx.drawText(textRenderer, "HUD EDITOR", width - 150, 8, 0xFF65C9FF, false);
        ctx.drawText(textRenderer, "Drag cards to move them; use arrows for precise positioning.", 6, height - 12, 0xFFE5F4FF, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (FY4XHud.El e : FY4XHud.El.values()) {
                java.util.List<String> lines = FY4XHud.lines(client, e);
                int x = FY4XHud.x(e), y = FY4XHud.y(e);
                int w = FY4XHud.width(client.textRenderer, lines), h = FY4XHud.height(lines);
                if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h) {
                    selected = e; dragging = true; dragX = mouseX - x; dragY = mouseY - y;
                    clearAndInit(); return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging && button == 0) {
            FY4XHud.setPos(selected, Math.max(0, Math.min(width - 20, (int)(mouseX - dragX))),
                Math.max(0, Math.min(height - 14, (int)(mouseY - dragY))));
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override public boolean shouldPause() { return false; }
}
