package com.alienmc.fy4x;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Lists flagged chunks (highest score first) with a Copy-coords button per row. */
public final class FY4XSusChunkScreen extends Screen {
    private static final int BG = 0xF20A111B, PANEL = 0xF2182636, EDGE = 0xFF48BFFF;
    private static final int MUTED = 0xFF9ABAD3, TEXT = 0xFFE5F4FF, WARN = 0xFFB36B00;
    private static final int ROW_H = 24;

    private int page = 0;

    public FY4XSusChunkScreen() { super(Text.literal("FY4X Sus Chunks")); }

    private int panelW() { return Math.min(width - 16, 400); }
    private int left() { return (width - panelW()) / 2; }
    private int rowsTop() { return 30; }
    private int perPage() { return Math.max(2, (height - rowsTop() - 62) / ROW_H); }

    @Override
    protected void init() {
        clearChildren();
        int left = left(), pw = panelW(), per = perPage();
        List<SusChunkScanner.Hit> hits = SusChunkScanner.hits();
        int pages = Math.max(1, (hits.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx >= hits.size()) break;
            SusChunkScanner.Hit h = hits.get(idx);
            addDrawableChild(ButtonWidget.builder(Text.literal("Copy"), b -> {
                if (client != null) client.keyboard.setClipboard(h.blockX() + " " + h.blockZ());
            }).dimensions(left + pw - 46, rowsTop() + i * ROW_H + 2, 42, ROW_H - 5).build());
        }
        int y1 = height - 48, y2 = height - 26;
        addDrawableChild(ButtonWidget.builder(Text.literal("Threshold −5"), b -> { SusChunkScanner.setThreshold(SusChunkScanner.threshold() - 5); clearAndInit(); })
            .dimensions(left, y1, 90, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Threshold +5"), b -> { SusChunkScanner.setThreshold(SusChunkScanner.threshold() + 5); clearAndInit(); })
            .dimensions(left + 94, y1, 90, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Clear list"), b -> { SusChunkScanner.clear(); clearAndInit(); })
            .dimensions(left + 188, y1, 70, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("◀"), b -> { page--; clearAndInit(); })
            .dimensions(left, y2, 30, 18).build()).active = page > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal("▶"), b -> { page++; clearAndInit(); })
            .dimensions(left + 34, y2, 30, 18).build()).active = page < pages - 1;
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> { if (client != null) client.setScreen(new FY4XScreen()); })
            .dimensions(left + pw - 60, y2, 60, 18).build());
    }

    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { /* drawn in render() */ }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, BG);
        int left = left(), pw = panelW(), per = perPage();
        List<SusChunkScanner.Hit> hits = SusChunkScanner.hits();
        int pages = Math.max(1, (hits.size() + per - 1) / per);
        boolean on = FY4XConfig.get(SusChunkScanner.KEY, false);
        ctx.drawText(textRenderer, "SUS CHUNKS  -  " + hits.size() + " flagged  (threshold " + SusChunkScanner.threshold() + ")", left, 10, 0xFF65C9FF, false);
        int bottom = rowsTop() + per * ROW_H;
        ctx.fill(left, rowsTop() - 2, left + pw, bottom + 2, PANEL);
        border(ctx, left, rowsTop() - 2, left + pw, bottom + 2, EDGE);
        if (hits.isEmpty()) {
            ctx.drawText(textRenderer, on ? "Nothing flagged yet. Walk around - loaded chunks are scanned every 3 seconds."
                                          : "Sus Chunk is OFF. Turn it on in the DONUT column.", left + 8, rowsTop() + 8, MUTED, false);
        }
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx >= hits.size()) break;
            SusChunkScanner.Hit h = hits.get(idx);
            int y = rowsTop() + i * ROW_H;
            if (i % 2 == 0) ctx.fill(left + 1, y, left + pw - 1, y + ROW_H - 1, 0x22003C78);
            ctx.drawText(textRenderer, "X " + h.blockX() + "  Z " + h.blockZ() + "   score " + h.score(), left + 6, y + 3, WARN, false);
            ctx.drawText(textRenderer, "chest " + h.chests() + " barrel " + h.barrels() + " shulker " + h.shulkers()
                + " hopper " + h.hoppers() + " spawner " + h.spawners() + " furnace " + h.furnaces(), left + 6, y + 13, MUTED, false);
        }
        ctx.drawText(textRenderer, "Page " + (page + 1) + "/" + pages, left + 70, height - 21, MUTED, false);
        ctx.drawText(textRenderer, "Heuristic: counts storage/spawner/hopper blocks the server sent. Natural structures can score too.", left, height - 8, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private static void border(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color); c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1, x1 + 1, y2, color); c.fill(x2 - 1, y1, x2, y2, color);
    }

    @Override public boolean shouldPause() { return false; }
}
