package com.alienmc.fy4x;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class FY4XClient implements ClientModInitializer {
    private static KeyBinding openGui, openStaff, openSus, toggleSus, toggleHud, toggleSser;

    private static KeyBinding bind(String id, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(id, InputUtil.Type.KEYSYM, key, KeyBinding.Category.MISC));
    }

    @Override
    public void onInitializeClient() {
        StaffTracker.load();
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.fy4x.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
            KeyBinding.Category.MISC
        ));
        openStaff = bind("key.fy4x.open_staff", GLFW.GLFW_KEY_UNKNOWN);
        openSus = bind("key.fy4x.open_sus", GLFW.GLFW_KEY_UNKNOWN);
        toggleSus = bind("key.fy4x.toggle_sus", GLFW.GLFW_KEY_UNKNOWN);
        toggleHud = bind("key.fy4x.toggle_hud", GLFW.GLFW_KEY_UNKNOWN);
        toggleSser = bind("key.fy4x.toggle_sser_mode", GLFW.GLFW_KEY_UNKNOWN);
        HudElementRegistry.addLast(Identifier.of("fy4x_client", "hud"), (ctx, tick) -> FY4XHud.render(ctx, MinecraftClient.getInstance()));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            StaffTracker.tick(client);
            SusChunkScanner.tick(client);
            while (openStaff.wasPressed()) if (client.currentScreen == null) client.setScreen(new FY4XStaffScreen(FY4XStaffScreen.Tab.LIVE));
            while (openSus.wasPressed()) if (client.currentScreen == null) client.setScreen(new FY4XSusChunkScreen());
            while (toggleSus.wasPressed()) FY4XConfig.set(SusChunkScanner.KEY, !FY4XConfig.get(SusChunkScanner.KEY, false));
            while (toggleHud.wasPressed()) FY4XConfig.set("HudMaster", !FY4XConfig.get("HudMaster", true));
            while (toggleSser.wasPressed()) FY4XConfig.set("SserMode", !FY4XConfig.get("SserMode", false));
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new FY4XScreen());
            }
        });
    }
}
