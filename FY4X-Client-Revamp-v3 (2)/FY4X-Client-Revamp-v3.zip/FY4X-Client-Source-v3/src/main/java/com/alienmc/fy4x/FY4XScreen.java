package com.alienmc.fy4x;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Module hub. Implemented: Sus Chunk, Staff screens/tracking, Fake Elytra. The rest are UI-only toggles. */
public final class FY4XScreen extends Screen {
    private static final int BG = 0xF20A111B;
    private static final int PANEL = 0xF2182636;
    private static final int EDGE = 0xFF48BFFF;
    private static final int MUTED = 0xFF9ABAD3;
    private static final int OUTER = 10, GAP = 6, MIN_COL = 92, ITEM_H = 20, TOP = 22, BOTTOM = 30;

    private enum Kind { PLACEHOLDER, TOGGLE, ACTION, LOCKED }
    private record Module(String name, Kind kind, boolean def, Runnable action) {}

    private final Map<String, List<Module>> categories = new LinkedHashMap<>();
    private int catPage = 0, itemPage = 0;

    public FY4XScreen() {
        super(Text.literal("FY4X Client"));
        categories.put("COMBAT", placeholders("Anchor Macro", "Auto Crystal", "Auto Hit Crystal", "Auto Inv Totem", "Auto Jump Reset", "Auto Totem", "Crystal Optimizer", "Double Anchor"));
        categories.put("MISC", placeholders("Auto Eat", "Auto Firework", "Auto Log", "Auto Loot", "Auto Mine", "Auto Tool", "Auto TPA", "Coro Snapper", "Elytra Glide"));
        List<Module> donut = placeholders("Anti Trap", "Auction Sniper", "Auto Sell", "Auto Spawner Sell", "Item Dropper", "Netherite Finder", "RTP Base Finder");
        donut.add(new Module(SusChunkScanner.KEY, Kind.TOGGLE, false, null));
        donut.add(new Module("Sus Chunk List", Kind.ACTION, false, () -> open(new FY4XSusChunkScreen())));
        categories.put("DONUT", donut);
        List<Module> render = placeholders("Krypton+", "HUD", "Player ESP", "Storage ESP", "Health Indicators", "Motion Blur");
        render.add(new Module("Fake Elytra", Kind.LOCKED, true, null));
        categories.put("RENDER", render);
        List<Module> staff = new ArrayList<>();
        staff.add(new Module("Staff List", Kind.ACTION, false, () -> open(new FY4XStaffScreen(FY4XStaffScreen.Tab.LIST))));
        staff.add(new Module("Staff Live", Kind.ACTION, false, () -> open(new FY4XStaffScreen(FY4XStaffScreen.Tab.LIVE))));
        staff.add(new Module(StaffTracker.LIVE_KEY, Kind.TOGGLE, true, null));
        staff.add(new Module(StaffTracker.NOTIFY_KEY, Kind.TOGGLE, false, null));
        staff.add(new Module(StaffTracker.AUTO_KEY, Kind.TOGGLE, true, null));
        categories.put("STAFF", staff);
        List<Module> clientCat = new ArrayList<>();
        clientCat.add(new Module("HUD Editor", Kind.ACTION, false, () -> open(new FY4XHudEditorScreen())));
        clientCat.add(new Module("Scoreboard Editor", Kind.ACTION, false, () -> open(new FY4XScoreboardScreen())));
        clientCat.add(new Module("Keycaps HUD", Kind.TOGGLE, true, null));
        clientCat.add(new Module("Potion Effects HUD", Kind.TOGGLE, true, null));
        clientCat.add(new Module("SSER Mode (UI only)", Kind.TOGGLE, false, null));
        clientCat.add(new Module("Controls: Options > Controls > Misc", Kind.LOCKED, true, null));
        categories.put("CLIENT", clientCat);
    }

    private static List<Module> placeholders(String... names) {
        List<Module> out = new ArrayList<>();
        for (String n : names) out.add(new Module(n, Kind.PLACEHOLDER, false, null));
        return out;
    }

    private void open(Screen s) { if (client != null) client.setScreen(s); }

    private int cols() { return Math.max(1, Math.min(5, (width - OUTER * 2 + GAP) / (MIN_COL + GAP))); }
    private int colW() { int c = cols(); return (width - OUTER * 2 - GAP * (c - 1)) / c; }
    private int panelH() { return Math.max(60, height - TOP - BOTTOM); }
    private int perPanel() { return Math.max(1, (panelH() - 28) / ITEM_H); }
    private int catPages() { return Math.max(1, (categories.size() + cols() - 1) / cols()); }

    private List<Map.Entry<String, List<Module>>> visible() {
        List<Map.Entry<String, List<Module>>> all = new ArrayList<>(categories.entrySet());
        int c = cols();
        int from = Math.min(catPage * c, Math.max(0, all.size() - 1));
        return all.subList(from, Math.min(all.size(), from + c));
    }

    private int itemPages() {
        int max = 1;
        for (Map.Entry<String, List<Module>> e : visible()) max = Math.max(max, e.getValue().size());
        return Math.max(1, (max + perPanel() - 1) / perPanel());
    }

    @Override
    protected void init() {
        clearChildren();
        catPage = Math.max(0, Math.min(catPage, catPages() - 1));
        itemPage = Math.max(0, Math.min(itemPage, itemPages() - 1));
        int colW = colW(), per = perPanel(), i = 0;
        for (Map.Entry<String, List<Module>> entry : visible()) {
            int x = OUTER + i++ * (colW + GAP);
            List<Module> list = entry.getValue();
            for (int r = 0; r < per; r++) {
                int idx = itemPage * per + r;
                if (idx >= list.size()) break;
                Module m = list.get(idx);
                int by = TOP + 26 + r * ITEM_H;
                ButtonWidget b = ButtonWidget.builder(label(m), btn -> press(m))
                    .dimensions(x + 4, by, colW - 8, ITEM_H - 2).build();
                if (m.kind() == Kind.LOCKED) b.active = false;
                addDrawableChild(b);
            }
        }
        int by = height - 24;
        addDrawableChild(ButtonWidget.builder(Text.literal("◀ Cat"), b -> { catPage--; itemPage = 0; clearAndInit(); })
            .dimensions(OUTER, by, 46, 18).build()).active = catPage > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal("Cat ▶"), b -> { catPage++; itemPage = 0; clearAndInit(); })
            .dimensions(OUTER + 50, by, 46, 18).build()).active = catPage < catPages() - 1;
        addDrawableChild(ButtonWidget.builder(Text.literal("◀ Items"), b -> { itemPage--; clearAndInit(); })
            .dimensions(OUTER + 104, by, 54, 18).build()).active = itemPage > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal("Items ▶"), b -> { itemPage++; clearAndInit(); })
            .dimensions(OUTER + 162, by, 54, 18).build()).active = itemPage < itemPages() - 1;
        addDrawableChild(ButtonWidget.builder(Text.literal("×"), b -> close())
            .dimensions(width - 30, 2, 24, 18).build());
    }

    private Text label(Module m) {
        boolean on = FY4XConfig.get(m.name(), m.def());
        switch (m.kind()) {
            case ACTION: return Text.literal("▶ " + m.name()).formatted(Formatting.AQUA);
            case LOCKED: return Text.literal("✔ " + m.name() + " (always on)").formatted(Formatting.GREEN);
            case TOGGLE: return Text.literal((on ? "● " : "○ ") + m.name()).formatted(on ? Formatting.GREEN : Formatting.WHITE);
            default: return Text.literal((on ? "● " : "○ ") + m.name()).formatted(on ? Formatting.GOLD : Formatting.DARK_GRAY);
        }
    }

    private void press(Module m) {
        if (m.kind() == Kind.ACTION) { m.action().run(); return; }
        if (m.kind() == Kind.LOCKED) return;
        FY4XConfig.set(m.name(), !FY4XConfig.get(m.name(), m.def()));
        clearAndInit();
    }

    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { /* drawn in render() */ }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, BG);
        int colW = colW(), panelH = panelH(), i = 0;
        for (Map.Entry<String, List<Module>> entry : visible()) {
            int x = OUTER + i++ * (colW + GAP);
            ctx.fill(x, TOP, x + colW, TOP + panelH, PANEL);
            border(ctx, x, TOP, x + colW, TOP + panelH, EDGE);
            ctx.drawCenteredTextWithShadow(textRenderer, entry.getKey(), x + colW / 2, TOP + 8, 0xFF65C9FF);
        }
        ctx.drawText(textRenderer, "FY4X CLIENT", OUTER, 5, 0xFF65C9FF, true);
        ctx.drawText(textRenderer, "SSER UI: " + (FY4XConfig.get("SserMode", false) ? "ON" : "OFF"), width - 110, 5, FY4XConfig.get("SserMode", false) ? 0xFF65C9FF : MUTED, false);
        ctx.drawText(textRenderer, "made by alienmc_1 on discord  •  RIGHT SHIFT", OUTER + 70, 5, MUTED, false);
        String legend = "Gray/gold = UI only (not implemented)   cat " + (catPage + 1) + "/" + catPages() + "  items " + (itemPage + 1) + "/" + itemPages();
        ctx.drawText(textRenderer, legend, OUTER + 224, height - 19, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private static void border(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color); c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1, x1 + 1, y2, color); c.fill(x2 - 1, y1, x2, y2, color);
    }

    @Override public boolean shouldPause() { return false; }
}
