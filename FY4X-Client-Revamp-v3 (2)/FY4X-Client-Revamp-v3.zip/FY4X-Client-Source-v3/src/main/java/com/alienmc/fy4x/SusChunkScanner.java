package com.alienmc.fy4x;

import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Heuristic "sus chunk" finder. It only looks at block entities the server already sent to your
 * client (storage, hoppers, spawners, furnaces...). A chunk with an unusually dense pile of them
 * scores high. Natural structures can also score; treat results as leads, not proof.
 */
public final class SusChunkScanner {
    public static final String KEY = "Sus Chunk";

    public record Hit(int chunkX, int chunkZ, int score, int chests, int barrels, int shulkers,
                      int hoppers, int spawners, int furnaces, int other) {
        public int blockX() { return chunkX * 16 + 8; }
        public int blockZ() { return chunkZ * 16 + 8; }
    }

    private static final Map<Long, Hit> HITS = new HashMap<>();
    private static final Set<Long> NOTIFIED = new HashSet<>();
    private static ClientWorld lastWorld;
    private static int ticks;

    private SusChunkScanner() {}

    private static long key(int x, int z) { return ((long) x << 32) ^ (z & 0xffffffffL); }

    public static int threshold() { return FY4XConfig.getInt("susThreshold", 25); }
    public static void setThreshold(int v) { FY4XConfig.setInt("susThreshold", Math.max(1, Math.min(500, v))); }

    public static synchronized void clear() { HITS.clear(); NOTIFIED.clear(); }

    public static synchronized List<Hit> hits() {
        List<Hit> out = new ArrayList<>(HITS.values());
        out.sort(Comparator.comparingInt(Hit::score).reversed());
        return out;
    }

    public static synchronized void tick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world != lastWorld) { HITS.clear(); NOTIFIED.clear(); lastWorld = world; }
        if (world == null || client.player == null) return;
        if (!FY4XConfig.get(KEY, false)) return;
        if (++ticks % 60 != 0) return;

        int radius = Math.min(client.options.getViewDistance().getValue(), 16);
        BlockPos p = client.player.getBlockPos();
        int cx = p.getX() >> 4, cz = p.getZ() >> 4;
        int threshold = threshold();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int x = cx + dx, z = cz + dz;
                WorldChunk chunk = world.getChunkManager().getWorldChunk(x, z);
                if (chunk == null) continue;
                int ch = 0, ba = 0, sh = 0, ho = 0, sp = 0, fu = 0, ot = 0;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof ChestBlockEntity) ch++;
                    else if (be instanceof BarrelBlockEntity) ba++;
                    else if (be instanceof ShulkerBoxBlockEntity) sh++;
                    else if (be instanceof HopperBlockEntity) ho++;
                    else if (be instanceof MobSpawnerBlockEntity) sp++;
                    else if (be instanceof AbstractFurnaceBlockEntity) fu++;
                    else if (be instanceof EnderChestBlockEntity || be instanceof DispenserBlockEntity || be instanceof BeaconBlockEntity) ot++;
                }
                int score = ch + ba + sh * 3 + ho * 2 + sp * 4 + fu + ot * 2;
                long k = key(x, z);
                if (score >= threshold) {
                    Hit hit = new Hit(x, z, score, ch, ba, sh, ho, sp, fu, ot);
                    HITS.put(k, hit);
                    if (NOTIFIED.add(k)) {
                        client.player.sendMessage(Text.literal("[FY4X] ").formatted(Formatting.AQUA)
                            .append(Text.literal("Sus chunk near " + hit.blockX() + ", " + hit.blockZ() + "  (score " + score + ")")
                                .formatted(Formatting.YELLOW)), false);
                    }
                } else {
                    HITS.remove(k);
                    NOTIFIED.remove(k);
                }
            }
        }
    }
}
