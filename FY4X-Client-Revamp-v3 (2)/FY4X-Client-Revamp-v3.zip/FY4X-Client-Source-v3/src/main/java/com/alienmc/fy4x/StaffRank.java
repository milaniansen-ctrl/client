package com.alienmc.fy4x;

import java.util.Locale;

/** Staff ranks, highest first. Tokens are matched against tab-list prefixes. */
public enum StaffRank {
    OWNER("Owner", 0xFF5555, "owner", "co owner", "founder"),
    SR_MANAGER("Sr Manager", 0xFF55FF, "sr manager", "senior manager"),
    MANAGER("Manager", 0xFF77FF, "manager"),
    JR_MANAGER("Jr Manager", 0xFF99FF, "jr manager", "junior manager"),
    DEVELOPER("Developer", 0x00D5FF, "developer"),
    DEV("Dev", 0x55CFFF, "dev"),
    SR_ADMIN("Sr Admin", 0xFF3B3B, "sr admin", "senior admin", "sr administrator"),
    ADMIN("Admin", 0xFF5555, "admin", "administrator"),
    JR_ADMIN("Jr Admin", 0xFF8080, "jr admin", "junior admin", "jr administrator"),
    SR_MOD("Sr Mod", 0xFFAA00, "sr mod", "senior mod", "sr moderator", "senior moderator"),
    MOD("Mod", 0xFFC24D, "mod", "moderator"),
    JR_MOD("Jr Mod", 0xFFD98A, "jr mod", "junior mod", "jr moderator", "junior moderator"),
    SR_SSER("Sr SSer", 0x2EE6A8, "sr sser", "senior sser", "sr screensharer", "senior screensharer"),
    SSER("SSer", 0x55F0BE, "sser", "screensharer", "screenshare", "ss"),
    JR_SSER("Jr SSer", 0x8CF5D3, "jr sser", "junior sser", "jr screensharer", "junior screensharer"),
    SR_HELPER("Sr Helper", 0x3DDC5B, "sr helper", "senior helper"),
    HELPER("Helper", 0x55FF55, "helper"),
    JR_HELPER("Jr Helper", 0xA0FFA0, "jr helper", "junior helper"),
    BUILDER("Builder", 0xFFE066, "builder"),
    TRAINEE("Trainee", 0xBBBBBB, "trainee", "trial", "trial helper");

    private final String display;
    private final int color;
    private final String[] tokens;

    StaffRank(String display, int color, String... tokens) {
        this.display = display;
        this.color = color;
        this.tokens = tokens;
    }

    public String display() { return display; }
    public int argb() { return 0xFF000000 | color; }

    /** Finds the best (longest) rank token in some text like "[Sr Admin] " or "Helper | ". */
    public static StaffRank detect(String text) {
        if (text == null || text.isEmpty()) return null;
        String padded = " " + text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim() + " ";
        StaffRank best = null;
        int bestLen = 0;
        for (StaffRank rank : values()) {
            for (String token : rank.tokens) {
                if (token.length() > bestLen && padded.contains(" " + token + " ")) {
                    best = rank;
                    bestLen = token.length();
                }
            }
        }
        return best;
    }

    public static StaffRank fromKey(String key) {
        if (key == null) return null;
        String k = key.trim();
        for (StaffRank r : values()) {
            if (r.name().equalsIgnoreCase(k) || r.display.equalsIgnoreCase(k)) return r;
        }
        return null;
    }
}
