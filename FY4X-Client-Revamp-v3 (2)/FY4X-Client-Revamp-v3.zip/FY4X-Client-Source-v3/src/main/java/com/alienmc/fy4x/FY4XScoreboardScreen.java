package com.alienmc.fy4x;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.LinkedHashMap;
import java.util.Map;

/** Local-only custom HUD scoreboard editor; it does not alter server scoreboard data. */
public final class FY4XScoreboardScreen extends Screen {
    private final Map<String, TextFieldWidget> fields = new LinkedHashMap<>();
    private static final String[] KEYS = {"score.title", "score.line1", "score.line2", "score.line3", "score.line4"};
    private static final String[] LABELS = {"Title", "Line 1", "Line 2", "Line 3", "Line 4"};

    public FY4XScoreboardScreen() { super(Text.literal("FY4X Scoreboard Editor")); }

    @Override protected void init() {
        clearChildren(); fields.clear();
        int left = width / 2 - 105;
        for (int i = 0; i < KEYS.length; i++) {
            int y = 38 + i * 39;
            TextFieldWidget field = new TextFieldWidget(textRenderer, left, y + 13, 210, 20, Text.literal(LABELS[i]));
            field.setMaxLength(48);
            field.setText(FY4XConfig.getString(KEYS[i], new String[]{"FY4X STATS", "Rank: Player", "Wins: 0", "K/D: 1.00", "Ping: --"}[i]));
            fields.put(KEYS[i], field); addDrawableChild(field);
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Save scoreboard"), b -> save())
            .dimensions(left, 38 + KEYS.length * 39 + 3, 102, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset defaults"), b -> {
            String[] defaults = {"FY4X STATS", "Rank: Player", "Wins: 0", "K/D: 1.00", "Ping: --"};
            for (int i = 0; i < KEYS.length; i++) fields.get(KEYS[i]).setText(defaults[i]);
        }).dimensions(left + 108, 38 + KEYS.length * 39 + 3, 102, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> { save(); if (client != null) client.setScreen(new FY4XScreen()); })
            .dimensions(width / 2 - 50, height - 28, 100, 20).build());
    }

    private void save() { fields.forEach((key, field) -> FY4XConfig.setString(key, field.getText())); }

    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xF20A111B);
        ctx.fill(width / 2 - 120, 20, width / 2 + 120, height - 20, 0xF2182636);
        ctx.drawCenteredTextWithShadow(textRenderer, "FY4X SCOREBOARD EDITOR", width / 2, 8, 0xFF65C9FF);
        for (int i = 0; i < LABELS.length; i++) ctx.drawText(textRenderer, LABELS[i], width / 2 - 105, 38 + i * 39, 0xFFE5F4FF, false);
        ctx.drawCenteredTextWithShadow(textRenderer, "Local HUD display only — server stats are unchanged", width / 2, height - 8, 0xFF9ABAD3);
        super.render(ctx, mouseX, mouseY, delta);
    }
    @Override public boolean shouldPause() { return false; }
}
