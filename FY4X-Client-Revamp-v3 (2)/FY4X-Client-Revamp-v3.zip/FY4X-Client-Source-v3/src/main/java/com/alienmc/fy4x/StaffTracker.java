package com.alienmc.fy4x;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Tracks staff using only what the server already shows your client: the player list (tab).
 * Ranks are read from tab prefixes and/or a saved roster (config/fy4x/staff.txt, lines "Name=RANK").
 * Vanished staff are not in the player list, so they cannot be seen.
 */
public final class StaffTracker {
    public static final String LIVE_KEY = "Staff Live Status";
    public static final String NOTIFY_KEY = "Staff Notifications";
    public static final String AUTO_KEY = "Auto Detect Ranks";

    public static final class Entry {
        public final String name;
        public StaffRank rank;
        public boolean online;
        public long lastSeen;
        Entry(String name, StaffRank rank) { this.name = name; this.rank = rank; }
    }

    private static final Map<String, Entry> ROSTER = new LinkedHashMap<>();
    private static Set<String> prevOnline = null;
    private static int ticks;

    private StaffTracker() {}

    private static Path file() { return FY4XConfig.dir().resolve("staff.txt"); }

    public static synchronized void load() {
        ROSTER.clear();
        Path f = file();
        if (!Files.exists(f)) return;
        try {
            for (String line : Files.readAllLines(f)) {
                String s = line.trim();
                if (s.isEmpty() || s.startsWith("#")) continue;
                int eq = s.indexOf('=');
                if (eq <= 0) continue;
                String name = s.substring(0, eq).trim();
                StaffRank rank = StaffRank.fromKey(s.substring(eq + 1));
                if (!name.isEmpty() && rank != null) ROSTER.put(name.toLowerCase(Locale.ROOT), new Entry(name, rank));
            }
        } catch (IOException ignored) {}
    }

    private static synchronized void save() {
        List<String> lines = new ArrayList<>();
        lines.add("# FY4X staff roster: Name=RANK  (ranks: " + rankNames() + ")");
        for (Entry e : ROSTER.values()) lines.add(e.name + "=" + e.rank.name());
        try { Files.write(file(), lines); } catch (IOException ignored) {}
    }

    private static String rankNames() {
        StringBuilder sb = new StringBuilder();
        for (StaffRank r : StaffRank.values()) { if (sb.length() > 0) sb.append(", "); sb.append(r.name()); }
        return sb.toString();
    }

    public static synchronized void add(String name, StaffRank rank) {
        String key = name.toLowerCase(Locale.ROOT);
        Entry e = ROSTER.get(key);
        if (e == null) ROSTER.put(key, new Entry(name, rank)); else e.rank = rank;
        save();
    }

    public static synchronized void remove(String name) {
        ROSTER.remove(name.toLowerCase(Locale.ROOT));
        save();
    }

    public static synchronized List<Entry> sorted(boolean onlyOnline) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : ROSTER.values()) if (!onlyOnline || e.online) out.add(e);
        out.sort(Comparator.<Entry>comparingInt(e -> e.rank.ordinal()).thenComparing(e -> e.name.toLowerCase(Locale.ROOT)));
        return out;
    }

    public static synchronized int onlineCount() {
        int n = 0;
        for (Entry e : ROSTER.values()) if (e.online) n++;
        return n;
    }

    public static synchronized int total() { return ROSTER.size(); }

    public static synchronized void tick(MinecraftClient client) {
        if (client.world == null || client.player == null || client.getNetworkHandler() == null) {
            if (prevOnline != null) {
                prevOnline = null;
                for (Entry e : ROSTER.values()) e.online = false;
            }
            return;
        }
        if (++ticks % 20 != 0) return;
        if (!FY4XConfig.get(LIVE_KEY, true)) return;

        boolean auto = FY4XConfig.get(AUTO_KEY, true);
        boolean notify = FY4XConfig.get(NOTIFY_KEY, false);
        PlayerListHud hud = client.inGameHud.getPlayerListHud();
        Set<String> now = new HashSet<>();
        boolean changed = false;

        for (PlayerListEntry pe : client.getNetworkHandler().getPlayerList()) {
            try {
                String name = pe.getProfile().name();
                if (name == null || name.isEmpty()) continue;
                String key = name.toLowerCase(Locale.ROOT);
                Entry e = ROSTER.get(key);
                if (auto) {
                    String shown = hud.getPlayerName(pe).getString();
                    StaffRank detected = StaffRank.detect(shown.replace(name, " "));
                    if (detected != null) {
                        if (e == null) { e = new Entry(name, detected); ROSTER.put(key, e); changed = true; }
                        else if (e.rank != detected) { e.rank = detected; changed = true; }
                    }
                }
                if (e != null) { now.add(key); e.lastSeen = System.currentTimeMillis(); }
            } catch (Exception ignored) {}
        }

        for (Map.Entry<String, Entry> me : ROSTER.entrySet()) me.getValue().online = now.contains(me.getKey());

        if (notify && prevOnline != null) {
            for (String key : now) if (!prevOnline.contains(key)) tell(client, ROSTER.get(key), "joined", Formatting.GREEN);
            for (String key : prevOnline) if (!now.contains(key) && ROSTER.get(key) != null) tell(client, ROSTER.get(key), "left", Formatting.RED);
        }
        prevOnline = now;
        if (changed) save();
    }

    private static void tell(MinecraftClient client, Entry e, String verb, Formatting color) {
        if (client.player == null || e == null) return;
        client.player.sendMessage(Text.literal("[FY4X] ").formatted(Formatting.AQUA)
            .append(Text.literal("[" + e.rank.display() + "] " + e.name + " " + verb).formatted(color)), false);
    }
}
