package com.alienmc.fy4x;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Movable light-blue HUD cards. Positions/enabled flags are saved in FY4XConfig. */
public final class FY4XHud {
    public enum El {
        WATERMARK("Watermark", 4, 4), STAFF("Staff Online", 4, 34), COORDS("Coordinates", 4, 100), FPS("FPS", 4, 120), SCOREBOARD("Custom Scoreboard", 4, 145), KEYCAPS("Keycaps", 14, 160), POTIONS("Potion Effects", 14, 245);
        public final String label; public final int dx, dy;
        El(String label, int dx, int dy) { this.label = label; this.dx = dx; this.dy = dy; }
    }

    private FY4XHud() {}

    public static int x(El e) { return FY4XConfig.getInt("hud.x." + e.name(), e.dx); }
    public static int y(El e) { return FY4XConfig.getInt("hud.y." + e.name(), e.dy); }
    public static void setPos(El e, int x, int y) { FY4XConfig.setInt("hud.x." + e.name(), x); FY4XConfig.setInt("hud.y." + e.name(), y); }
    public static boolean on(El e) {
        String key = e == El.KEYCAPS ? "Keycaps HUD" : e == El.POTIONS ? "Potion Effects HUD" : "hud.on." + e.name();
        return FY4XConfig.get(key, true);
    }
    public static void setOn(El e, boolean v) {
        String key = e == El.KEYCAPS ? "Keycaps HUD" : e == El.POTIONS ? "Potion Effects HUD" : "hud.on." + e.name();
        FY4XConfig.set(key, v);
    }

    public static List<String> lines(MinecraftClient c, El e) {
        List<String> out = new ArrayList<>();
        switch (e) {
            case WATERMARK: out.add("FY4X Client"); out.add("by alienmc_1"); break;
            case STAFF: {
                List<StaffTracker.Entry> on = StaffTracker.sorted(true);
                out.add("Staff online (" + on.size() + ")");
                for (int i = 0; i < Math.min(8, on.size()); i++) out.add("[" + on.get(i).rank.display() + "] " + on.get(i).name);
                break;
            }
            case COORDS:
                if (c.player != null) out.add("XYZ " + (int) Math.floor(c.player.getX()) + " " + (int) Math.floor(c.player.getY()) + " " + (int) Math.floor(c.player.getZ()));
                else out.add("XYZ -");
                break;
            case FPS: out.add(c.getCurrentFps() + " FPS"); break;
            case KEYCAPS:
                out.add("KEYCAPS");
                out.add("W");
                out.add("A   S   D");
                out.add("LMB     RMB");
                break;
            case POTIONS:
                out.add("EFFECTS");
                if (c.player != null) {
                    for (net.minecraft.entity.effect.StatusEffectInstance effect : c.player.getStatusEffects()) {
                        String name = effect.getEffectType().value().getName().getString();
                        int seconds = Math.max(0, effect.getDuration()) / 20;
                        String time = String.format("%d:%02d", seconds / 60, seconds % 60);
                        String level = effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : "";
                        out.add(name + level + "  " + time);
                    }
                }
                if (out.size() == 1) out.add("No active effects");
                break;
            case KEYCAPS:
                out.add("KEYCAPS"); out.add("W"); out.add("A   S   D"); out.add("LMB     RMB");
                break;
            case POTIONS:
                out.add("EFFECTS");
                if (c.player != null) {
                    for (net.minecraft.entity.effect.StatusEffectInstance effect : c.player.getStatusEffects()) {
                        String name = effect.getEffectType().value().getName().getString();
                        int seconds = Math.max(0, effect.getDuration()) / 20;
                        String time = String.format("%d:%02d", seconds / 60, seconds % 60);
                        String level = effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : "";
                        out.add(name + level + "  " + time);
                    }
                }
                if (out.size() == 1) out.add("No active effects");
                break;
            case SCOREBOARD:
                out.add(FY4XConfig.getString("score.title", "FY4X STATS"));
                out.add(FY4XConfig.getString("score.line1", "Rank: Player"));
                out.add(FY4XConfig.getString("score.line2", "Wins: 0"));
                out.add(FY4XConfig.getString("score.line3", "K/D: 1.00"));
                out.add(FY4XConfig.getString("score.line4", "Ping: --"));
                break;
        }
        return out;
    }

    public static int width(TextRenderer tr, List<String> lines) {
        int w = 0;
        for (String s : lines) w = Math.max(w, tr.getWidth(s));
        return w + 8;
    }

    public static int height(List<String> lines) { return lines.size() * 10 + 4; }

    public static void render(DrawContext ctx, MinecraftClient c) {
        if (c.options.hudHidden || !FY4XConfig.get("HudMaster", true)) return;
        for (El e : El.values()) if (on(e)) drawCard(ctx, c, e, false);
    }

    public static void drawCard(DrawContext ctx, MinecraftClient c, El e, boolean selected) {
        List<String> lines = lines(c, e);
        TextRenderer tr = c.textRenderer;
        int x = x(e), y = y(e), w = width(tr, lines), h = height(lines);
        if (e == El.KEYCAPS) {
            drawKeycaps(ctx, c, x, y, selected);
            return;
        }
        ctx.fill(x, y, x + w, y + h, 0xCC142638);
        ctx.fill(x, y, x + 2, y + h, 0xFF48BFFF);
        if (selected) {
            ctx.fill(x - 1, y - 1, x + w + 1, y, 0xFFFFFFFF); ctx.fill(x - 1, y + h, x + w + 1, y + h + 1, 0xFFFFFFFF);
            ctx.fill(x - 1, y, x, y + h, 0xFFFFFFFF); ctx.fill(x + w, y, x + w + 1, y + h, 0xFFFFFFFF);
        }
        for (int i = 0; i < lines.size(); i++) ctx.drawText(tr, lines.get(i), x + 5, y + 3 + i * 10, i == 0 ? 0xFF65C9FF : 0xFFE5F4FF, false);
    }
}

    private static void drawKeycaps(DrawContext ctx, MinecraftClient c, int x, int y, boolean selected) {
        int box = 22, idle = 0xEE26384B, active = 0xFF48BFFF;
        ctx.fill(x, y, x + 98, y + 78, 0xCC142638);
        ctx.fill(x, y, x + 2, y + 78, 0xFF48BFFF);
        drawKey(ctx, c, "W", x + 38, y + 4, box, c.options.forwardKey.isPressed(), idle, active);
        drawKey(ctx, c, "A", x + 12, y + 30, box, c.options.leftKey.isPressed(), idle, active);
        drawKey(ctx, c, "S", x + 38, y + 30, box, c.options.backKey.isPressed(), idle, active);
        drawKey(ctx, c, "D", x + 64, y + 30, box, c.options.rightKey.isPressed(), idle, active);
        boolean lmb = org.lwjgl.glfw.GLFW.glfwGetMouseButton(c.getWindow().getHandle(), org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_1) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        boolean rmb = org.lwjgl.glfw.GLFW.glfwGetMouseButton(c.getWindow().getHandle(), org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_2) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        drawKey(ctx, c, "LMB", x + 8, y + 56, 38, lmb, idle, active);
        drawKey(ctx, c, "RMB", x + 52, y + 56, 38, rmb, idle, active);
        if (selected) {
            ctx.fill(x - 1, y - 1, x + 99, y, 0xFFFFFFFF);
            ctx.fill(x - 1, y + 78, x + 99, y + 79, 0xFFFFFFFF);
        }
    }

    private static void drawKey(DrawContext ctx, MinecraftClient c, String label, int x, int y, int w, boolean pressed, int idle, int active) {
        ctx.fill(x, y, x + w, y + 21, pressed ? active : idle);
        ctx.fill(x, y + 19, x + w, y + 21, 0xFF101923);
        ctx.drawCenteredTextWithShadow(c.textRenderer, label, x + w / 2, y + 6, 0xFFFFFFFF);
    }

    private static void drawKeycaps(DrawContext ctx, MinecraftClient c, int x, int y, boolean selected) {
        int box = 22, idle = 0xEE26384B, active = 0xFF48BFFF;
        ctx.fill(x, y, x + 98, y + 78, 0xCC142638); ctx.fill(x, y, x + 2, y + 78, 0xFF48BFFF);
        drawKey(ctx, c, "W", x + 38, y + 4, box, c.options.forwardKey.isPressed(), idle, active);
        drawKey(ctx, c, "A", x + 12, y + 30, box, c.options.leftKey.isPressed(), idle, active);
        drawKey(ctx, c, "S", x + 38, y + 30, box, c.options.backKey.isPressed(), idle, active);
        drawKey(ctx, c, "D", x + 64, y + 30, box, c.options.rightKey.isPressed(), idle, active);
        boolean lmb = org.lwjgl.glfw.GLFW.glfwGetMouseButton(c.getWindow().getHandle(), org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_1) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        boolean rmb = org.lwjgl.glfw.GLFW.glfwGetMouseButton(c.getWindow().getHandle(), org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_2) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        drawKey(ctx, c, "LMB", x + 8, y + 56, 38, lmb, idle, active); drawKey(ctx, c, "RMB", x + 52, y + 56, 38, rmb, idle, active);
        if (selected) { ctx.fill(x-1,y-1,x+99,y,0xFFFFFFFF); ctx.fill(x-1,y+78,x+99,y+79,0xFFFFFFFF); }
    }
    private static void drawKey(DrawContext ctx, MinecraftClient c, String label, int x, int y, int w, boolean pressed, int idle, int active) {
        ctx.fill(x,y,x+w,y+21,pressed?active:idle); ctx.fill(x,y+19,x+w,y+21,0xFF101923);
        ctx.drawCenteredTextWithShadow(c.textRenderer,label,x+w/2,y+6,0xFFFFFFFF);
    }
