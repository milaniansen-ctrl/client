package com.alienmc.fy4x;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Staff LIVE (who is online right now) and Staff LIST (full roster with add/remove). */
public final class FY4XStaffScreen extends Screen {
    public enum Tab { LIVE, LIST }

    private static final int BG = 0xF20A111B, PANEL = 0xF2182636, EDGE = 0xFF48BFFF;
    private static final int MUTED = 0xFF9ABAD3, TEXT = 0xFFE5F4FF, GREEN = 0xFF1E9E3A, GRAY = 0xFF6B7F94;
    private static final int ROW_H = 17;

    private Tab tab;
    private int page = 0;
    private String pendingName = "";
    private StaffRank pendingRank = StaffRank.HELPER;

    public FY4XStaffScreen() { this(Tab.LIVE); }

    public FY4XStaffScreen(Tab tab) {
        super(Text.literal("FY4X Staff"));
        this.tab = tab;
    }

    private int panelW() { return Math.min(width - 16, 400); }
    private int left() { return (width - panelW()) / 2; }
    private int rowsTop() { return 56; }
    private int perPage() { return Math.max(3, (height - rowsTop() - (tab == Tab.LIST ? 82 : 52)) / ROW_H); }

    @Override
    protected void init() {
        clearChildren();
        int left = left(), pw = panelW();
        addDrawableChild(ButtonWidget.builder(Text.literal("LIVE").formatted(tab == Tab.LIVE ? Formatting.AQUA : Formatting.WHITE),
            b -> { tab = Tab.LIVE; page = 0; clearAndInit(); }).dimensions(left, 28, 60, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("LIST").formatted(tab == Tab.LIST ? Formatting.AQUA : Formatting.WHITE),
            b -> { tab = Tab.LIST; page = 0; clearAndInit(); }).dimensions(left + 64, 28, 60, 18).build());

        List<StaffTracker.Entry> rows = StaffTracker.sorted(tab == Tab.LIVE);
        int per = perPage();
        int pages = Math.max(1, (rows.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));

        if (tab == Tab.LIST) {
            for (int i = 0; i < per; i++) {
                int idx = page * per + i;
                if (idx >= rows.size()) break;
                final String name = rows.get(idx).name;
                addDrawableChild(ButtonWidget.builder(Text.literal("−").formatted(Formatting.RED),
                    b -> { StaffTracker.remove(name); clearAndInit(); })
                    .dimensions(left + pw - 22, rowsTop() + i * ROW_H, 18, ROW_H - 1).build());
            }
            int ay = height - 52;
            TextFieldWidget field = new TextFieldWidget(textRenderer, left + 38, ay, 110, 18, Text.literal("Name"));
            field.setMaxLength(16);
            field.setText(pendingName);
            field.setChangedListener(s -> pendingName = s);
            addDrawableChild(field);
            addDrawableChild(ButtonWidget.builder(Text.literal("Rank: " + pendingRank.display()), b -> {
                pendingRank = StaffRank.values()[(pendingRank.ordinal() + 1) % StaffRank.values().length];
                clearAndInit();
            }).dimensions(left + 154, ay, 120, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Add"), b -> {
                String n = pendingName.trim();
                if (n.matches("[A-Za-z0-9_.]{1,16}")) { StaffTracker.add(n, pendingRank); pendingName = ""; clearAndInit(); }
            }).dimensions(left + 280, ay, 50, 18).build());
        }

        int by = height - 26;
        addDrawableChild(ButtonWidget.builder(Text.literal("◀"), b -> { page--; clearAndInit(); })
            .dimensions(left, by, 30, 18).build()).active = page > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal("▶"), b -> { page++; clearAndInit(); })
            .dimensions(left + 34, by, 30, 18).build()).active = page < pages - 1;
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> { if (client != null) client.setScreen(new FY4XScreen()); })
            .dimensions(left + pw - 60, by, 60, 18).build());
    }

    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) { /* drawn in render() */ }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, BG);
        int left = left(), pw = panelW();
        List<StaffTracker.Entry> rows = StaffTracker.sorted(tab == Tab.LIVE);
        int per = perPage();
        int pages = Math.max(1, (rows.size() + per - 1) / per);

        String title = tab == Tab.LIVE
            ? "STAFF LIVE  -  " + StaffTracker.onlineCount() + " online"
            : "STAFF LIST  -  " + StaffTracker.total() + " tracked, " + StaffTracker.onlineCount() + " online";
        ctx.drawText(textRenderer, title, left, 10, 0xFF65C9FF, false);

        int listBottom = rowsTop() + per * ROW_H;
        ctx.fill(left, rowsTop() - 3, left + pw, listBottom + 2, PANEL);
        border(ctx, left, rowsTop() - 3, left + pw, listBottom + 2, EDGE);

        if (rows.isEmpty()) {
            String msg = tab == Tab.LIVE ? "No staff visible in the player list right now." : "Roster is empty. Add names below or join a server that shows ranks in tab.";
            ctx.drawText(textRenderer, msg, left + 8, rowsTop() + 6, MUTED, false);
        }
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx >= rows.size()) break;
            StaffTracker.Entry e = rows.get(idx);
            int y = rowsTop() + i * ROW_H;
            if (i % 2 == 0) ctx.fill(left + 1, y, left + pw - 1, y + ROW_H - 1, 0x22003C78);
            String tag = "[" + e.rank.display() + "]";
            ctx.drawText(textRenderer, tag, left + 6, y + 4, e.rank.argb(), true);
            ctx.drawText(textRenderer, e.name, left + 12 + textRenderer.getWidth(tag), y + 4, TEXT, false);
            String status = e.online ? "● ONLINE" : "○ offline";
            int sx = left + pw - (tab == Tab.LIST ? 30 : 10) - textRenderer.getWidth(status);
            ctx.drawText(textRenderer, status, sx, y + 4, e.online ? GREEN : GRAY, false);
        }
        if (tab == Tab.LIST) ctx.drawText(textRenderer, "Name:", left, height - 47, MUTED, false);
        ctx.drawText(textRenderer, "Page " + (page + 1) + "/" + pages, left + 70, height - 21, MUTED, false);
        String note = FY4XConfig.get(StaffTracker.LIVE_KEY, true)
            ? "Reads the server's player list. Vanished staff cannot be seen."
            : "Live tracking is OFF - enable 'Staff Live Status' in the STAFF column.";
        ctx.drawText(textRenderer, note, left, height - 8, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private static void border(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1, y1, x2, y1 + 1, color); c.fill(x1, y2 - 1, x2, y2, color);
        c.fill(x1, y1, x1 + 1, y2, color); c.fill(x2 - 1, y1, x2, y2, color);
    }

    @Override public boolean shouldPause() { return false; }
}
