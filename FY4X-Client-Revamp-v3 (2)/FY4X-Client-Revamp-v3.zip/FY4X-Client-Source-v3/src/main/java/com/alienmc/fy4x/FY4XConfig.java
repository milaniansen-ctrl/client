package com.alienmc.fy4x;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tiny persistent settings store: .minecraft/config/fy4x/modules.properties */
public final class FY4XConfig {
    private static final Properties PROPS = new Properties();
    private static boolean loaded;

    private FY4XConfig() {}

    public static Path dir() {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("fy4x");
        try { Files.createDirectories(d); } catch (IOException ignored) {}
        return d;
    }

    private static synchronized void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        Path f = dir().resolve("modules.properties");
        if (Files.exists(f)) {
            try (InputStream in = Files.newInputStream(f)) { PROPS.load(in); } catch (IOException ignored) {}
        }
    }

    private static synchronized void save() {
        Path f = dir().resolve("modules.properties");
        try (OutputStream out = Files.newOutputStream(f)) { PROPS.store(out, "FY4X Client settings"); } catch (IOException ignored) {}
    }

    public static synchronized boolean get(String key, boolean def) {
        ensureLoaded();
        String v = PROPS.getProperty("m." + key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    public static synchronized void set(String key, boolean value) {
        ensureLoaded();
        PROPS.setProperty("m." + key, Boolean.toString(value));
        save();
    }

    public static synchronized String getString(String key, String def) {
        ensureLoaded();
        return PROPS.getProperty("s." + key, def);
    }

    public static synchronized void setString(String key, String value) {
        ensureLoaded();
        PROPS.setProperty("s." + key, value == null ? "" : value);
        save();
    }

    public static synchronized int getInt(String key, int def) {
        ensureLoaded();
        try { return Integer.parseInt(PROPS.getProperty("i." + key, Integer.toString(def))); }
        catch (NumberFormatException e) { return def; }
    }

    public static synchronized void setInt(String key, int value) {
        ensureLoaded();
        PROPS.setProperty("i." + key, Integer.toString(value));
        save();
    }
}
