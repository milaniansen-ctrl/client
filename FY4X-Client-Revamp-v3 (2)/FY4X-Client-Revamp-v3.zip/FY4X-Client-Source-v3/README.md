# FY4X Client source

Fabric client mod for Minecraft 1.21.11 / Java 21. Press **Right Shift** for the hub (change it in Options > Controls > Misc).

## Build
`gradle build` (or `build.bat` on Windows). Needs internet so Gradle can fetch Minecraft + Fabric.
Output: `build/libs/fy4x-client-0.3.1.jar` (ignore the `-sources` jar).

## What is actually implemented
- **Staff List / Staff Live** (STAFF column): ranks Owner, Sr Manager, Manager, Jr Manager, Developer, Dev,
  Sr/Admin/Jr Admin, Sr/Mod/Jr Mod, Sr/SSer/Jr SSer, Sr/Helper/Jr Helper, Builder, Trainee.
  Ranks are read from the server's player-list (tab) prefixes and saved to `config/fy4x/staff.txt`
  (`Name=RANK`). You can also add/remove names in the LIST tab. Vanished staff cannot be seen.
  Optional chat alerts when staff join/leave ("Staff Notifications").
- **Sus Chunk** (DONUT column): scores loaded chunks by storage/hopper/spawner/furnace density and lists
  flagged chunks with copy-coords. Heuristic only; natural structures can trigger it. Threshold adjustable.
- **Fake Elytra** (RENDER column): iron chestplate shows the elytra item model (inventory/hotbar/ground).
  Always on while the jar is installed. It does not change the worn model on your body.

Everything shown in gray/gold in the hub (Auto Crystal, ESP, etc.) is still a UI-only toggle.

## v0.3.1 additions
- Light-blue theme, branded "FY4X Client - made by alienmc_1 on discord".
- HUD Editor (CLIENT column): watermark, staff online, coordinates, FPS cards. Pick a card and move it with the arrow buttons (no mouse-drag).
- Key binds (Options > Controls > Misc, search "FY4X"): hub, staff live, sus chunks, toggle sus scan, toggle HUD.


## Revamp notes
- Refreshed the hub, staff screens, and HUD editor to a dark navy / light-blue palette inspired by the supplied references.
- Keybinds remain configurable through Minecraft's Controls menu (search `FY4X`).
- The scoreboard is not a fake-stat/evidence-spoofing system. No screen-share or anti-cheat evasion behavior is included.
- The SSER/staff ranks are labels for the staff tracker; the client does not detect vanished staff or guarantee that every server rank format is recognized.


## Revamp update

- HUD elements can now be dragged directly with the mouse in the HUD Editor. Arrow controls remain available.
- Added a Custom Scoreboard editor with editable title and four lines. This is a local HUD overlay only; it does not change server-side scoreboard data or stats.
- Added a configurable SSER UI mode keybind under Options → Controls → Misc. It only toggles the client-side UI state and does not hide cheats or bypass anti-cheat/review.
- Settings are saved under `.minecraft/config/fy4x/modules.properties`.


## HUD additions in v0.3.2

- **Keycaps HUD:** live W/A/S/D and left/right mouse button visualizer, movable in the HUD editor.
- **Potion Effects HUD:** lists active status effects, amplifier level, and remaining time.
- Both are configurable from the CLIENT category and can be positioned in the HUD editor.

## Module status and scope

Implemented features include HUD, scoreboard editor, staff tracker/screens, and a heuristic suspicious-chunk scanner. Combat automation, player/storage ESP, auto-sell/auction automation, and similar gameplay-advantage modules remain placeholders rather than working modules. Build and test against the target Minecraft/Fabric versions before use.
